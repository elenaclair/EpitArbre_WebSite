#include <stdio.h>
#include <stdlib.h>
#include "bintree.h"

// Inorder traversal
void inorderTraversal(struct rnode* root)
{
  if (root == NULL) return;
  inorderTraversal(root->left);
  printf("%d-", root->item);
  inorderTraversal(root->right);
}

// Preorder traversal
void preorderTraversal(struct rnode* root) 
{
  if (root == NULL) return;
  printf("%d-", root->item);
  preorderTraversal(root->left);
  preorderTraversal(root->right);
}

// Postorder traversal
void postorderTraversal(struct rnode* root) 
{
  if (root == NULL) return;
  postorderTraversal(root->left);
  postorderTraversal(root->right);
  printf("%d-", root->item);
}

// Create a new Node
struct rnode* createNode(int value) 
{
  struct rnode* newNode = malloc(sizeof(struct rnode));
  newNode->item = value;
  newNode->left = NULL;
  newNode->right = NULL;

  return newNode;
}

// Insert on the left of the node
struct rnode* insertLeft(struct rnode* root, int value) 
{
  root->left = createNode(value);
  return root->left;
}

// Insert on the right of the node
struct rnode* insertRight(struct rnode* root, int value) 
{
  root->right = createNode(value);
  return root->right;
}

// Function to print binary tree in 2D
// It does reverse inorder traversal
void print2DUtil(struct rnode *root, int space)
{
    // Base case
    if (root == NULL)
        return;
 
    // Increase distance between levels
    space += 5;
 
    // Process right child first
    print2DUtil(root->right, space);
 
    // Print current node after space
    // count
    printf("\n");
    for (int i = 5; i < space; i++)
        printf(" ");
    printf("%d\n", root->item);
 
    // Process left child
    print2DUtil(root->left, space);
}
 
// Wrapper over print2DUtil()
void print2D(struct rnode *root)
{
   // Pass initial space count as 0
   print2DUtil(root, 0);
}

// Main part for tests (No interface yet)
/*
int main() 
	
{
  struct rnode* root = createNode(1);
  insertLeft(root, 2);
  insertRight(root, 4);
  insertLeft(root->left, 3);
  insertLeft(root->right, 6);
  insertRight(root->right, 5);

  print2D(root);

  postorderTraversal(root);
 
  printf("Done\n");

}
*/

