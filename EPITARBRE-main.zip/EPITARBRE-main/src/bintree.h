#include "stdio.h"
#include "stdlib.h"

#ifndef TREE_H
#define TREE_H

struct rnode 
{
  int item;
  struct rnode* left;
  struct rnode* right;
};

void inorderTraversal(struct rnode* root);
void preorderTraversal(struct rnode* root);
void postorderTraversal(struct rnode* root);
struct rnode* createNode(int value);
struct rnode* insertLeft(struct rnode* root, int value);
struct rnode* insertRight(struct rnode* root, int value);
void print2DUtil(struct rnode *root, int space);
void print2D(struct rnode *root);

#endif
