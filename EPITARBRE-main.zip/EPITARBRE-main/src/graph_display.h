#include <stdio.h>
#include <stdlib.h>

#ifndef GRAPH_DISPLAY_H
#define GRAPH_DISPLAY_H

SDL_Surface* Convert(char* path);

#endif
