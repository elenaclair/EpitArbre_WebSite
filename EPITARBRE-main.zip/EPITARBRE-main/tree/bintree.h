#include "stdio.h"
#include "stdlib.h"

#ifndef TREE_H
#define TREE_H

struct node 
{
  int item;
  struct node* left;
  struct node* right;
};

void inorderTraversal(struct node* root);
void preorderTraversal(struct node* root);
void postorderTraversal(struct node* root);
struct node* createNode(value);
struct node* insertLeft(struct node* root, int value);
struct node* insertRight(struct node* root, int value);
void print2DUtil(struct node *root, int space);
void print2D(struct node *root);

#endif